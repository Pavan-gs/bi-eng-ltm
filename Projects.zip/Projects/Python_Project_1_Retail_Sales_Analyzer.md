# PYTHON PROJECT 1 — Retail Sales EDA & Analysis
**Marks: 20 | Difficulty: Medium | Technology: Pandas + Matplotlib**

## 1. Problem Statement
A retail company records daily sales transactions across stores. Build a Pandas analyzer that creates the sales table, cleans invalid records, performs EDA, creates derived columns, summarizes store/category performance, identifies high-value orders, and visualizes sales.

Complete `solution.py`. Do not change class name, method names, parameter lists, or return types. Every analysis method receives a complete DataFrame and must work independently.

## 2. Input Schema
`OrderID` — unique order ID  
`OrderDate` — supplied date; keep as supplied  
`Store` — store name  
`Category` — product category  
`Quantity` — units sold  
`UnitPrice` — price per unit  
`Discount` — percentage  
`PaymentStatus` — Paid, Pending, Cancelled

## 3. Class
```python
class RetailSalesAnalyzer:
    # No constructor state is required
```

## 4. Operations

### 1. Create sales DataFrame
```python
def create_sales_df(self, sales_data: list) -> pd.DataFrame:
```
Create one row per inner list, use the eight columns in exact schema order, preserve input order.

### 2. Clean sales data
```python
def clean_sales_data(self, df: pd.DataFrame) -> pd.DataFrame:
```
Retain rows with no missing values, `Quantity > 0`, `UnitPrice > 0`, `0 <= Discount <= 100`, and valid payment status. Return a copy, original column order, retained row order, zero-based index. Do not modify input.

### 3. Add sales amount
```python
def add_sales_amount(self, df: pd.DataFrame) -> pd.DataFrame:
```
Return a copy and add `SalesAmount` as the last column:
`Quantity * UnitPrice * (1 - Discount / 100)`.

### 4. Store performance summary
```python
def store_performance_summary(self, df: pd.DataFrame) -> pd.DataFrame:
```
Group by Store. Return `Store, OrderCount, TotalSales, AverageOrderValue`. Round average to 2 decimals and sort by Store ascending.

### 5. High-value orders
```python
def high_value_orders(self, df: pd.DataFrame, threshold: float) -> pd.DataFrame:
```
Keep orders where SalesAmount is strictly greater than threshold. Return `OrderID, Store, Category, SalesAmount`, sorted by SalesAmount descending.

### 6. Category analysis
```python
def category_analysis(self, df: pd.DataFrame) -> pd.DataFrame:
```
Return `Category, TotalQuantity, TotalSales, AverageDiscount`. Sort by TotalSales descending; round AverageDiscount to 2 decimals.

### 7. EDA
```python
def sales_eda(self, df: pd.DataFrame) -> dict:
```
Return `row_count, column_count, missing_values, unique_stores, unique_categories, total_sales, average_sales`.

### 8. Visualization
```python
def plot_store_sales(self, df: pd.DataFrame):
```
Create a Matplotlib bar chart of total SalesAmount by Store with title and axis labels.

## 5. Dataset
```python
sales_data = [
 [1001,"2024-06-01","Mumbai","Electronics",2,45000,5,"Paid"],
 [1002,"2024-06-01","Pune","Furniture",3,8000,10,"Paid"],
 [1003,"2024-06-02","Mumbai","Electronics",1,60000,0,"Pending"],
 [1004,"2024-06-02","Nashik","Grocery",10,500,5,"Paid"],
 [1005,"2024-06-03","Pune","Electronics",2,30000,15,"Paid"],
 [1006,"2024-06-03","Mumbai","Furniture",4,7000,0,"Cancelled"],
 [1007,"2024-06-04","Nashik","Grocery",8,600,0,"Paid"],
 [1008,"2024-06-04","Pune","Furniture",2,12000,5,"Pending"],
 [1009,"2024-06-05","Mumbai","Electronics",3,25000,20,"Paid"],
 [1010,"2024-06-05","Nashik","Furniture",1,15000,10,"Paid"],
 [1011,"2024-06-06","Pune","Grocery",12,450,0,"Paid"],
 [1012,"2024-06-06","Mumbai","Electronics",0,40000,5,"Paid"],
 [1013,"2024-06-07","Pune","Furniture",2,-5000,5,"Paid"],
 [1014,"2024-06-07","Nashik","Electronics",1,55000,25,"Paid"],
 [1015,"2024-06-08","Mumbai","Grocery",5,700,110,"Paid"],
 [1016,"2024-06-08","Pune","Electronics",2,35000,10,"Paid"]
]
```
